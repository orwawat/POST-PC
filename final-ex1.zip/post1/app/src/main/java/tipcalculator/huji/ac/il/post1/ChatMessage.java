package tipcalculator.huji.ac.il.post1;

/**
 * Created by orwa on 3/13/2017.
 */

public class ChatMessage {
    public boolean left;
    public String message;

    public ChatMessage(boolean left , String message) {
        // TODO Auto-generated constructor stub
        super();
        this.left=left;
        this.message = message;
    }
}